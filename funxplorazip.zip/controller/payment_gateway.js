const Coinpayments = require("coinpayments");
const { queryDb } = require("../helper/adminHelper");
const moment = require("moment");
exports.getPaymentGateway = async (req, res) => {
  const { amount, userid } = req.body;
  const transactonNo = Date.now();
  if (!amount || !userid)
    return res.status(201).json({
      msg: "Everything is required",
    });
  if (Number(amount) <= 0)
    return res.status(201).json({
      msg: "Amount should be grater than 0$",
    });

  const num_amount = Number(amount);
  if (typeof num_amount !== "number")
    return res.status(201).json({
      msg: "Amount should be in number data type",
    });
  try {
    const credentials = {
      key: "b60e80d201409b395acb1decc90ef6b92ef5c9949c5a1296a6aad404004cd909",
      secret:
        "bA88ae65d9f1a6fb223dE5f07a0C1D725AD4e9366580626b31057D7f94066fbb",
    };

    const client = new Coinpayments(credentials);

    const CoinpaymentsCreateTransactionOpts = {
      currency1: "USDT.BEP20",
      currency2: "USDT.BEP20",
      amount: Number(num_amount),
      buyer_email: "suretradefx24@gmail.com",
      address: "", // Optional, for some currencies
      buyer_name: "Arun Kumar", // Optional
      item_name: "", // Optional
      item_number: "", // Optional
      invoice: transactonNo,
      custom: "", // Optional
      ipn_url: "", // Optional
      success_url: "https://funxplora.com/",
      cancel_url: "https://funxplora.com/",
    };

    const response = await client.createTransaction(
      CoinpaymentsCreateTransactionOpts
    );

    const params = [
      Number(userid),
      "USDT.BEP20",
      Number(num_amount),
      `${transactonNo}`,
      JSON.stringify({
        txtamount: Number(num_amount),
        coin: "USDT.BEP20",
      }),
      JSON.stringify(response),
      `${response?.address}`,
      `${response?.status_url}`,
      `${response?.qrcode_url}`,
    ];
    await saveDataIntoTable(params);
    res.status(200).json({
      data: response,
    });
  } catch (e) {
    console.log(e);
    const params = [
      Number(userid),
      "USDT.BEP20",
      Number(num_amount),
      `${transactonNo}`,
      JSON.stringify({
        txtamount: Number(num_amount),
        coin: "USDT.BEP20",
      }),
      JSON.stringify(e),
      "",
      "",
      "",
    ];
    await saveDataIntoTable(params);
    res.status(400).json({
      error: "Something went wrong",
    });
  }
};

async function saveDataIntoTable(params) {
  try {
    const query = `INSERT INTO m05_fund_gateway(user_id,to_coin,amt,order_id,request,response,address,status_url,qrcode_url)
        VALUES(
        ?,
        ?,
        ?,
        ?,
        ?,
        ?,
        ?,
        ?,
        ?
        );`;
    const response_Gateway_data = await queryDb(query, params)
      .then((result) => {
        return result;
      })
      .catch((e) => {
        console.log(
          "Something went in insert data in table at the usdt gateway"
        );
      });
  } catch (e) {
    console.log(e);
  }
}

exports.getCallBack = async (req, res) => {
  try {
    const response = req.body;
    const invoice = response?.invoice;
    const status = response?.status_text;
    const success_amount = response?.amount1;
    console.log(response, "this is response get by the call back api");
    const str = "Complete";
    if (status?.toUpperCase() === str?.toUpperCase()) {
      /// data set into m05_fund_gateway
      const query = `UPDATE  m05_fund_gateway SET callback = ?,success_date = ?,success_amount = ?,status = ? WHERE  order_id = ?;`;
      await queryDb(query, [
        JSON.stringify(response),
        `${moment(Date.now())?.format("YYYY-MM-DD HH:mm:ss")}`,
        Number(success_amount),
        "success",
        String(invoice),
      ])
        .then((result) => {})
        .catch((e) => {
          console.log("Error in callback inserting");
        });

      // get user id from the m05_fund_gateway table ;
      const get_user_id = `SELECT user_id FROM m05_fund_gateway WHERE order_id = ?;`;
      await queryDb(get_user_id, [String(invoice)])
        .then(async (result) => {
          if (result?.length <= 0) return;
          const user_id = result?.[0]?.user_id;
          //////////////// insert in leser ////////////////////
          const query_for_inserting_in_leser = `CALL sp_coin_payment_update_leser_payin(?,?,?);`;
          const leser_params = [
            Number(user_id),
            Number(success_amount || 0)?.toFixed(4),
            String(invoice),
          ];
          await queryDb(query_for_inserting_in_leser, leser_params)
            .then((result) => {})
            .catch((e) => {
              console.log("Error in inserting in leser transaction.");
            });
        })
        .catch((e) => {
          console.log("Error in finding userid from the fund_gateway table.");
        });
      // data add into leser
    } else {
      const query = `UPDATE m05_fund_gateway 
        SET callback = ?, success_date = ?, status = ? 
        WHERE order_id = ?;`;
      try {
        const result = await queryDb(query, [
          JSON.stringify({ response }),
          moment().format("YYYY-MM-DD HH:mm:ss"),
          "failed",
          String(invoice),
        ]);
        console.log("Update successful:", result);
      } catch (e) {
        console.error("Error in callback inserting:", e);
      }
    }
    res.status(200).json({
      msg: "We get response now.",
    });
  } catch (e) {
    console.log(e);
  }
};
